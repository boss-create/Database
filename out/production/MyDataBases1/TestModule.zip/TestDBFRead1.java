import DB.DBMS;
import com.linuxense.javadbf.DBFException;
import com.linuxense.javadbf.DBFField;
import com.linuxense.javadbf.DBFReader;
import dbf.DBFContent;

import java.io.*;
import java.util.*;

public class TestDBFRead1 {
    public static void main(String[] args){
        DBFReader reader = null;// 从dbf中获取内容
        List<Map<String, Object>> list = new LinkedList<>();
        DBFContent dbfContent = new DBFContent();  //实例化DBFContent
        InputStream in = null;
        try {
            in = new FileInputStream(new File(DBMS.DATA_PATH + "student"
                    + ".dbf"));
            reader = new DBFReader(in);// 将文件从文件流中读入。

            int fieldCount = reader.getFieldCount();// 读取字段个数
            int rowNum = reader.getRecordCount();// 获取有多少条记录

            // 设置DBFContent的参数
            dbfContent.setFieldCount(fieldCount);
            dbfContent.setRecordCount(rowNum);

            List<DBFField> fields = new ArrayList<>(); //得到每个字段
            for (int i = 0; i < fieldCount; i++) {
                // 得到DBF文件的Fields
                fields.add(reader.getField(i));
            }
            dbfContent.setFields(fields);

            Object[] rowObjects;
            List<Map<String, Object>> cons = new ArrayList<>();   //记录每条记录内容
            while ((rowObjects = reader.nextRecord()) != null) {  // 用Object[] 对象取出一行行记录
                Map<String, Object> map = new HashMap<>();        // map 为每个字段当前的字段名和所映射的这条记录一个toString
                for (int i = 0; i < fieldCount; i++) {
                    String s = rowObjects[i].toString().trim(); //去除列宽多余的空白
                    System.out.println("s:"+s);

                    map.put(fields.get(i).getName(), s);

                }
                cons.add(map);
                System.out.println("map:"+map);
            }

            dbfContent.setContents(cons);  //将我们所读取到的记录数据初始化dbfContents


        } catch (FileNotFoundException e) {
            System.err.println("解析dbf数据过程中，没有找到dbf文件");  //标准错误输出流
            e.printStackTrace();
        } catch (DBFException e) {
            System.err.println("解析dbf数据过程中，dbf文件读取异常");
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
    }
