/*
* 自定义的处理sql语句语法的异常
* */
package DB;

public class MyException extends Exception {

    public String exception;

    public MyException(String string) {
        exception = string;
    }

}
