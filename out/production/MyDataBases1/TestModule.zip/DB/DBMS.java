package DB;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dbf.DBFContent;
import module.Alter;
import module.Create;
import module.Delete;
import module.Drop;
import module.Insert;
import module.Select;
import module.Update;
import org.jetbrains.annotations.NotNull;

public class DBMS {

    public static final String DATA_PATH = "data\\";// 数据库存储路径
    public static final String LOG_PATH = "systemLog\\";// 系统操作日志存储路径
    public static final String EXC_PATH = "exception"; //系统异常日志存储路径
    private static File constraintFile;// 数据字典文件
    private DBMSForm form;// 显示窗口

    static {
        String constraint = DATA_PATH + "student1.dbf";
        constraintFile = new File(constraint); // 约束记录数据文件
        if (!constraintFile.exists())
            try {
                constraintFile.createNewFile(); //返回值表示文件是否创建成功
            } catch (IOException e) {
                e.printStackTrace();

            }
    }

    public DBMS(DBMSForm form) {
        this.form = form;
    }

    // 根据sql语句开头判断操作类型
    public void parseSQL(@NotNull String sql) throws MyException {
        if (sql.trim().startsWith("create")) {  //trim 去掉两端空格
            Create create = parseCreate(sql);
            DBFContent content = create.executeSQL();
            form.setOutput(content, "建表成功");
            form.clearInput();
            recordSystemLogs(sql);
        } else if (sql.trim().toLowerCase().startsWith("insert")) {
            Insert insert = parseInsert(sql);
            DBFContent content = insert.excuteSQL();
            form.setOutput(content, "插入成功");
            form.clearInput();
            recordSystemLogs(sql);
        } else if (sql.trim().toLowerCase().startsWith("delete")) {
            Delete delete = parseDelete(sql);
            DBFContent content = delete.executeSQL();
            form.setOutput(content, "删除成功");
            form.clearInput();
            recordSystemLogs(sql);
        } else if (sql.trim().toLowerCase().startsWith("update")) {
            Update update = parseUpdate(sql);
            DBFContent content = update.executeSQL();
            form.setOutput(content, "修改成功");
            form.clearInput();
            recordSystemLogs(sql);
        } else if (sql.trim().toLowerCase().startsWith("select")) {
            Select selectSql = parseSelect(sql);
            DBFContent content = selectSql.executeSQL();
            form.setOutput(content, null);
            form.clearInput();
            recordSystemLogs(sql);
        } else if (sql.trim().toLowerCase().startsWith("alter")) {
            Alter alter = parseAlter(sql);
            String title = alter.executeSQL();
            form.setOutput(title);
            form.clearInput();
            recordSystemLogs(sql);
        } else if (sql.trim().toLowerCase().startsWith("drop")) {
            Drop drop = parseDrop(sql);
            String title = drop.executeSQL();
            form.setOutput(title);
            form.clearInput();
            recordSystemLogs(sql);
        }
    }

    public String getStackTraceInfo(Exception e) {  //捕获printStackTrace转为字符串
        StringWriter sw = null;
        PrintWriter pw = null;
        try {
            sw = new StringWriter();
            pw = new PrintWriter(sw);
            e.printStackTrace(pw);//将出错的栈信息输出到printWriter中
            pw.flush();
            sw.flush();
            return sw.toString();
        } catch (Exception ex) {
            return "printStackTrace()转换错误";
        } finally {
            if (sw != null) {
                try {
                    sw.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            if (pw != null) {
                pw.close();
            }
        }

    }

    // 记录系统日志
    public void recordSystemLogs(String sql) {
        File file = new File(LOG_PATH + "db1.log");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Date date = new Date(System.currentTimeMillis());// 获取系统时间
        try (BufferedWriter buf = new BufferedWriter(new FileWriter(file,true))){
            buf.write((date + " -->> : " + sql + "\n"));
            buf.flush();
        } catch (IOException e) {
//            e.printStackTrace();
            recordExceptionLogs(e);
        }
    }

    public void recordExceptionLogs(Exception ee){
        File f1 = new File(EXC_PATH+"exc1.log");
        if(!f1.exists()){
            try{
            f1.createNewFile();
        }catch(IOException e){
                e.printStackTrace();
            }
        }
        Date date = new Date(System.currentTimeMillis());
        try (BufferedWriter buf = new BufferedWriter(new FileWriter(f1,true))){
            buf.write((date + " -->> : "+getStackTraceInfo(ee) + "\n"));
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    // Insert语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public Insert parseInsert(String sql) throws MyException {
        sql = sql.toLowerCase().replaceAll("\\s{2,}"," ").trim();
        if(sql.endsWith(";")){
            sql = sql.substring(0,sql.length()-1);
        }
        String insert = sql.substring(0,sql.indexOf(" "));
        sql = sql.substring(sql.indexOf(" ")+1);
        String into = sql.substring(0,sql.indexOf(" "));
        sql = sql.substring(sql.indexOf(" ")+1);
        String tableName = sql.substring(0,sql.indexOf("("));
        tableName = tableName.trim();
        String fieldString = sql.substring(sql.indexOf("(") + 1,
                sql.indexOf(")"));
        fieldString = fieldString.replaceAll("\\s","");
        sql = sql.substring(sql.indexOf(")") + 1).trim();
        String values = sql.substring(0, sql.indexOf("(")).trim();
        sql = sql.substring(sql.indexOf(" ") + 1);
        String valueString = sql.substring(sql.indexOf("(") + 1,
                sql.indexOf(")"));
        valueString = valueString.replaceAll("\\s","");
//        System.out.println("valueString1:"+valueString);

        return new Insert(tableName, fieldString, valueString);
    }

    // Create语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public Create parseCreate(String sql) throws MyException {
        sql = sql.toLowerCase().replaceAll("\\s{2,}", " ");
        sql = sql.trim();
        if(!sql.endsWith(";")){
            throw new MyException("结尾缺少;");
        }
//        System.out.println("sql:"+sql);
        String create = sql.substring(0, sql.indexOf(" "));
//        System.out.println("create:"+create);
        if(!"create".equals(create)){
            throw new MyException("create拼写错误!");
        }
        sql = sql.substring(sql.indexOf(" ")+1);
//        System.out.println("sql:"+sql);
        String table = sql.substring(0,sql.indexOf(" "));
        if(!"table".equals(table)){
            throw new MyException("table拼写错误!");
        }
//        System.out.println("table:"+table);

        sql = sql.substring(sql.indexOf(" ")+1);
        String tableName = sql.substring(0, sql.indexOf("("));
//        System.out.println("tableName:"+tableName);

        String fieldString = sql.substring(sql.indexOf("(")+1,sql.indexOf(";")).trim();
        fieldString = fieldString.substring(0,fieldString.length()-1);
//        System.out.println("fieldString:"+fieldString);
        String[] fieldEntry = fieldString.split(",");

        int len = fieldEntry.length;
        for(int i = 0; i < len; i++){
            fieldEntry[i] = fieldEntry[i].trim();
        }
        List<String[]> list = new ArrayList<>();
        for (String fields : fieldEntry) {
            String[] field = fields.split(" ");
            list.add(field);
        }
        return new Create(list, tableName);
    }

    // Select语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public static Select parseSelect(String sql) throws MyException {
        sql = sql.trim();
        sql = sql.toLowerCase();
        sql = sql.replaceAll("[\\s|,]{1,}", " ");

//        System.out.println("sql:" + sql);
        if (sql.endsWith(";"))
            sql = sql.substring(0, sql.length() - 1);
        String[] select = sql.split(" ");

        int length = select.length;
        String[] selectCopy = new String[length];

        int cnt = 0;
        for(int i = 0; i < length; i++){
            if(i+2<length && (select[i + 1].equals("<=") || select[i + 1].equals(">=") || select[i + 1].equals("=="))){
                selectCopy[cnt++] = select[i] + select[i+1] + select[i+2];
                i += 2;
            }
            else{
                selectCopy[cnt++] = select[i];
            }
//            System.out.println("cnt:"+cnt);
        }

        int count = 0;
        for(int i = 0; i < cnt; i++){
            if(i+1<length && (selectCopy[i+1].startsWith(">=")|| selectCopy[i+1].startsWith("<=") || selectCopy[i+1].startsWith("=="))){
                selectCopy[count++] = selectCopy[i] + selectCopy[i+1];
                i += 1;
            }else if(selectCopy[i].endsWith(">=") || selectCopy[i].endsWith("<=") || selectCopy[i].endsWith("==")){
                selectCopy[count++] = selectCopy[i]+select[i+1];
                i += 1;
            }
            else{
                selectCopy[count++] = selectCopy[i];
            }
        }

        String[] selectEnd = new String[count];
        int start = 0,end = count-1;
        while(start <= end){
            selectEnd[start] = selectCopy[start];
            selectEnd[end] = selectCopy[end];
            start++;
            end--;
        }
        return new Select(selectEnd);
    }

    // Delete语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public Delete parseDelete(String sql) throws MyException {
        sql = sql.toLowerCase().trim();
        sql = sql.replaceAll("\\s{2,}"," ");
//        System.out.println("sql:"+sql);

        if(sql.endsWith(";")){
            sql = sql.substring(0,sql.length()-1).trim();
        }else{
            throw new MyException("句子未以;结尾!");
        }
        String delete = sql.substring(0, sql.indexOf(" "));
        if(!delete.equals("delete")){
            throw new MyException("delete 拼写错误!");
        }
//        System.out.println("delete:"+delete);
        sql = sql.substring(sql.indexOf(" ")+1);
//        System.out.println("sql:"+sql);

        String from = sql.substring(0, sql.indexOf(" "));
        if(!from.equals("from")){
            throw new MyException("from 拼写错误!");
        }
//        System.out.println("from:"+from);

        sql = sql.substring(sql.indexOf(" ")+1);
//        System.out.println("sql:"+sql);

        String tableName = sql.substring(0,sql.indexOf(" "));
//        System.out.println("tableName:"+tableName);
        String whereString = null;
        if(sql.contains("where")) {
            sql = sql.substring(sql.indexOf(" ") + 1);
//            System.out.println("sql:" + sql);

            String where = sql.substring(0, sql.indexOf(" "));
            if(!where.equals("where")){
                throw new MyException("where 拼写错误!");
            }
//            System.out.println("where:" + where);

            sql = sql.substring(sql.indexOf(" ") + 1);
//            System.out.println("sql:" + sql);

            whereString = sql.trim().replaceAll("\\s+", "");
//            System.out.println("whereString:" + whereString);
        }
        return new Delete(tableName, whereString);
    }

    // Update语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public Update parseUpdate(String sql) throws MyException {
        sql = sql.toLowerCase().trim();
        sql = sql.replaceAll("\\s{2,}"," ");
        System.out.println("sql:"+sql);
        if(!sql.endsWith(";")){
            throw new MyException("句子没有以;结尾");
        }
        String update = sql.substring(0,sql.indexOf(" "));
//        System.out.println("update:"+update);
        if(!update.equals("update")){
            throw new MyException("update 拼写错误");
        }
        sql = sql.substring(sql.indexOf(" ")+1);
        String tableName = sql.substring(0,sql.indexOf(" "));
//        System.out.println("tableName:"+tableName);

        sql = sql.substring(sql.indexOf(" ")+1);
        String set = sql.substring(0,sql.indexOf(" "));
//        System.out.println("set:"+set);
        if(!set.equals("set")){
            throw new MyException("set 拼写错误");
        }
        sql = sql.substring(sql.indexOf(" ")+1);
//        System.out.println("sql:"+sql);

        String updateString = null;
        String whereString = null;
        if(sql.contains("where")){
            updateString = sql.substring(0,sql.indexOf("where")).replaceAll("\\s+","");
//            System.out.println("updateString:"+updateString);
            sql = sql.substring((sql.indexOf("where")));
//            System.out.println("sql:"+sql);

            String where = sql.substring(sql.indexOf("where"),sql.indexOf(" "));
            System.out.println("where:"+where);
            if(!where.equals("where")){
                throw new MyException("where 拼写错误");
            }
            whereString = sql.substring(sql.indexOf(" ")+1,sql.indexOf(";")).replaceAll("\\s+","");
//            System.out.println("whereString:"+whereString);
        }
        else{
            updateString = sql.substring(0,sql.length()-1).replaceAll("\\s+","");
//            System.out.println("updateString:"+updateString);
        }

        return new Update(tableName, updateString, whereString);
    }

    // Alter语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public Alter parseAlter(String sql) throws MyException {
        sql = sql.toLowerCase().trim();
        sql = sql.replaceAll("\\s{2,}"," ");

        if(!sql.endsWith(";")){
            throw new MyException("句子没有以;结尾");
        }

        String alter = sql.substring(0,sql.indexOf(" "));
//        System.out.println("alter:"+alter);
        if(!alter.equals(alter)){
            throw new MyException("alter 拼写错误!");
        }
        sql = sql.substring(sql.indexOf(" ")+1);
//        System.out.println("sql:"+sql);
        String table = sql.substring(0,sql.indexOf(" "));
//        System.out.println("table:"+table);
        if(!table.equals("table")){
            throw new MyException("table 拼写错误!");
        }
        sql = sql.substring(sql.indexOf(" ")+1);
        String tableName = sql.substring(0,sql.indexOf(" "));

        sql = sql.substring(sql.indexOf(" ")+1);
        String type = sql.substring(0,sql.indexOf(" "));
//        System.out.println("sql:"+sql);
//        System.out.println("type:"+type);

        sql = sql.substring(sql.indexOf(" ")+1,sql.length()-1).trim();

//        System.out.println("sql:"+sql);
        return new Alter(tableName, type, sql);
    }

    // Drop语句预处理，去除空白符，分号，根据语句特点分解提取语句信息
    public Drop parseDrop(String sql) throws MyException {
        sql = sql.toLowerCase().trim();
        sql = sql.replaceAll("\\s{2,}"," ");
//        System.out.println("sql:"+sql);

        if(!sql.endsWith(";")){
            throw new MyException("句子没有以;结尾");
        }
        String drop = sql.substring(0,sql.indexOf(" "));
//        System.out.println("drop:"+drop);

        sql = sql.substring(sql.indexOf(" ")+1);
        String table = sql.substring(0,sql.indexOf(" "));
//        System.out.println("table:"+table);

        String tableName = sql.substring(sql.indexOf(" ")+1,sql.length()-1).trim();
//        System.out.println("tableName:"+tableName);

        return new Drop(tableName);
    }
}
