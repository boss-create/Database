/*
* DBMS.java：系统的运行中心，通过输入的SQL语句开头将SQL语句传入到相应的子模块，
* 并对SQL语句进行标准化预处理；通过对输入的正确的SQL语句实现对系统日志的记录
*
* 通过swing 动作监听联系到各个事件
* */
package DB;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.Map;

import javax.swing.*;

import com.intellij.ui.JBColor;
import com.linuxense.javadbf.DBFField;
import dbf.DBFContent;
import DB.DBMS;
public class DBMSForm {

    private final DBMS dbms;
    private JTextArea showText, inputText;// 显示框与输入框
    private final JFrame frame;// 窗口框架
    private static DBMSForm form;

    //使用单例模式创建一个窗口
    static{
        form = new DBMSForm();
    }

    private DBMSForm() {
        dbms = new DBMS(this);
        JPanel panel = new JPanel();
        panel.setLayout(null);// 清空布局，使用像素位定义布局

        showText = new JTextArea();
        showText.setBackground(JBColor.WHITE);
        showText.setText("\n\n\n\n\t\t\t\t欢迎进入数据库系统！");
        showText.setLineWrap(true);// 设置自动换行
        showText.setEditable(false);// 设置不可编辑
        showText.setSize(780, 470);// 设置大小
        showText.setLocation(0, 0);// 设置位置
        panel.add(showText);

        JLabel label = new JLabel("请输入SQL语句：");
        label.setSize(780, 12);
        label.setLocation(0, 470);
        panel.add(label);

        inputText = new JTextArea();
        inputText.setBackground(Color.decode("#E6E6E6"));
        inputText.setSize(780, 50);
        inputText.setLineWrap(true);
        inputText.setLocation(0, 482);
        panel.add(inputText);

        // 提交按钮
        // 提交按钮
        JButton okButton = new JButton("提交");
        okButton.setLocation(360, 530);
        okButton.setSize(60, 35);
        okButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {  //将
                String sql = inputText.getText(); //传入sql语句
                if (sql == null || sql.length() == 0 || sql.replaceAll("\\s+","").equals("")) {
                    showText.setText("请不要输入空SQL语句!");
                } else {
                    try {
                        dbms.parseSQL(sql);
                    } catch (MyException e1) {
                        showText.setText(e1.exception);
                    }
                }
            }
        });
        panel.add(okButton);

        frame = new JFrame("叭叭叭数据库管理系统");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        int windowWidth = frame.getWidth(); // 获得窗口宽
        int windowHeight = frame.getHeight(); // 获得窗口高
        Toolkit kit = Toolkit.getDefaultToolkit(); // 定义工具包
        Dimension screenSize = kit.getScreenSize(); // 获取屏幕的尺寸
        int screenWidth = screenSize.width; // 获取屏幕的宽
        int screenHeight = screenSize.height; // 获取屏幕的高
        frame.setLocation(screenWidth / 2 - windowWidth / 2, screenHeight / 2
                - windowHeight / 2);// 设置窗口居中显示

        frame.add(panel);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeFrame();
            }
        });
        frame.setVisible(true);
    }

    private void closeFrame()
    {
//        System.out.println("调用窗体关闭功能");
        ImageIcon img1 = new ImageIcon("img\\Exit.png");
        img1.setImage(img1.getImage().getScaledInstance(30,30, Image.SCALE_DEFAULT));
        int result = JOptionPane.showConfirmDialog(null, "是否要退出？", "退出确认", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,img1);
        if (result == JOptionPane.YES_OPTION)
            frame.dispose();
    }

    public static void main(String[] args) {
        try {
            Class.forName("DB.DBMSForm");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();

        }
    }

    public void setOutput(String output) {
        showText.setText("------------------------------------------------------------------------------------------"
                + output
                + "------------------------------------------------------------------------------------------");
    }

    // 设置窗口输出
    public void setOutput(DBFContent content, String title) {
        StringBuilder builder = new StringBuilder(); //类似StringBuffer  速度快但是线程不安全
        if (title != null) {
            builder.append(
                    "------------------------------------------------------------------------------------------")
                    .append(title)
                    .append("--------------------------------------------------------------------------------------\n");
        }
        builder.append("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        List<DBFField> fields = content.getFields();
        for (int i = 0; i < fields.size(); i++) {
            if (i == fields.size() - 1) {
                builder.append("      ").append(fields.get(i).getName())
                        .append("\n");
            } else
                builder.append("      ").append(fields.get(i).getName())
                        .append("       |");
        }
        builder.append("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        for (int i = 0; i < content.getRecordCount(); i++) {
            Map<String, Object> map = content.getContents().get(i);
            for (int j = 0; j < fields.size(); j++) {
                if (j == fields.size() - 1) {
                    builder.append("     ")
                            .append(map.get(fields.get(j).getName()))
                            .append("\n");
                } else
                    builder.append("     ")
                            .append(map.get(fields.get(j).getName()))
                            .append("     |");
            }
            builder.append("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        }
        showText.setText(builder.toString());
    }

    // 清空输入框
    public void clearInput() {
        inputText.setText("");
    }

    // 接收异常，在窗口输出
    public void receiveException(String e) {
        showText.setText(e);
    }
}
